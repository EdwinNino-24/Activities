/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package models;

import java.io.Serializable;

/**
 *
 * @author Edwin Niño
 */
public class Person implements Serializable{
    
    //private int id;
    //private static int autoId;
    private String firstname;
    private String lastname;
    private String numberPhone;

    public Person(String firstname, String lastname, String numberPhone) {
        //this.id = autoId++;
        this.firstname = firstname;
        this.lastname = lastname;
        this.numberPhone = numberPhone;
    }
    
    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getNumberPhone() {
        return numberPhone;
    }

    public void setNumberPhone(String numberPhone) {
        this.numberPhone = numberPhone;
    }

    @Override
    public String toString() {
        return "PERSONA: " + /*"#" + id +*/
                "\n Nombres: " + firstname + "\n Apellidos: " + lastname + "\n Numero celular: " + numberPhone;
    }
   
}
