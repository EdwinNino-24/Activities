/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presenters;

import controllers.PersonController;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import models.Person;

/**
 *
 * @author Edwin Niño
 */
public class Main {
    
    static ArrayList<Person> people = new ArrayList<Person>();
    Scanner scanner = new Scanner(System.in);
    
    public Main(){
        run();
    }
    
    public void run() {
        //createTestData();
        String banner =    "__________________________________________________________________________________________________\n" +
                               " ________________________________________________________________________________________________\n" +
                               "|                                         _______________                         [ManagePeople®]|\n" +
                               "|--------------------------------------- | MANAGE PEOPLE | --------------------------------------|\n" +
                               "|________________________________________________________________________________________________|\n" +
                               "__________________________________________________________________________________________________";
        System.out.println(banner);
        int optionMenu = 0;
        
        do {
            
            String mainMenu =  " ________________________________________________________________________________________________\n" +
                               "|                                        ________________                                        |\n" +
                               "|-------------------------------------- | MENÚ PRINCIPAL | --------------------------------------|\n" +
                               "|________________________________________________________________________________________________|\n" +
                               " ________________________________________________________________________________________________\n" +
                               "|                         [--->] 1. Registrar persona nueva------------>(1)                      |\n" +
                               "|                         [--->] 2. Mostrar personas registradas------->(2)                      |\n" +
                               "|                         [--->] 3. Remover persona de los registros--->(3)                      |\n" +
                               "|                         [--->] 4. Cerrar el programa----------------->(4)                      |\n" +
                               "|________________________________________________________________________________________________|";
            System.out.println(mainMenu);
            
            String formatOption = 
                               "__________________________________________________________________________________________________";
            String format1 =   " ________________________________________________________________________________________________ ";
            String format2 =   "|________________________________________________________________________________________________|";
       
            
            try{
                System.out.println(formatOption);
                optionMenu = Integer.parseInt(scanner.nextLine());
                System.out.println(formatOption);
            }
            catch(NumberFormatException x){ 
            }    
            
            switch(optionMenu) {
		case 1:
                    addPerson();
                    break;
                case 2:
                    showPeople();
                    break;
                case 3:
                    removePerson();
                    break;
                case 4:
                    System.out.println(formatOption);
                    System.out.println(" EL PROGRAMA SE HA CERRADO EXITOSAMENTE...");
                    System.out.println(formatOption);
                    break;
		default:
                    System.out.println(formatOption);
                    System.out.println(" SELECCIONE UNA OPCION QUE SE ENCUENTRE EN EL MENU...");
                    System.out.println(formatOption);
                    break;
            }
        }while(optionMenu != 4);
    
    }
    
    public void addPerson(){
        
        String formatOption = 
                               "__________________________________________________________________________________________________";
        System.out.print(" Ingrese sus nombres: ");
        String firstName = scanner.nextLine();
        System.out.println(formatOption);
        System.out.print(" Ingrese sus apellidos: ");
        String lastName = scanner.nextLine();
        System.out.println(formatOption);
        System.out.print(" Ingrese su numero celular: ");
        String numberPhone = scanner.nextLine();
        Person person = new Person(firstName,lastName,numberPhone);
        people.add(person);
        
        PersonController personController = new PersonController();
        try {
            personController.save(people);
        } 
        catch (IOException e) {
            e.printStackTrace();
        }
        
        System.out.println(formatOption);
        System.out.println(" LA PERSONA SE HA INGRESADO AL SISTEMA EXITOSAMENTE...");
        
        System.out.println(formatOption);
            System.out.println("                     PRESIONE CUALQUIER TECLA PARA REGRESAR AL MENÚ PRINCIPAL                     ");
            System.out.println(formatOption);
            scanner.nextLine();
        
    }
    
    public void showPeople(){
        
        PersonController personController = new PersonController();
        try {
            people = personController.read();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        
        String formatOption = "__________________________________________________________________________________________________";
        
        if(people == null || people.isEmpty()){
            System.out.println(" AUN NO SE ENCUENTRAN REGISTROS EN EL SISTEMA...");
        }
        else{
            int id = 0;
            for (Person person : people) {
                System.out.println("ID--> #" + id);
                System.out.println(person.toString());
                System.out.println();
                id++;
            }
        }
        
        System.out.println(formatOption);
        System.out.println("                     PRESIONE CUALQUIER TECLA PARA REGRESAR AL MENÚ PRINCIPAL                     ");
        System.out.println(formatOption);
        scanner.nextLine();
        
    }
    
    
    public void removePerson(){
        
        String formatOption = 
                               "__________________________________________________________________________________________________";
        
        if(people == null || people.isEmpty()){
            System.out.println(" AUN NO SE ENCUENTRAN REGISTROS EN EL SISTEMA..."); 
        }
        else{
            try{
                int id = 0;
                for (Person person : people) {
                    System.out.println("ID--> #" + id);
                    System.out.println(person.toString());
                    System.out.println();
                    id++;
                }
                
                System.out.println(formatOption);
                System.out.print(" Ingrese el ID de la persona a remover: ");
                int removeId = scanner.nextInt();
                System.out.println(formatOption);
                people.remove(removeId);
                System.out.println(" LA PERSONA SE HA REMOVIDO EXITOSAMENTE DEL SISTEMA...");
                
                PersonController personController = new PersonController();
                try {
                    personController.save(people);
                } 
                catch (IOException e) {
                    e.printStackTrace();
                }
                
            }
            catch(IndexOutOfBoundsException x){
                System.out.println(" EL ID INGRESADO NO SE ENCUENTRA REGISTRADO EN EL SISTEMA...");
            }
            
        }
        
        System.out.println(formatOption);
        System.out.println("                     PRESIONE CUALQUIER TECLA PARA REGRESAR AL MENÚ PRINCIPAL                     ");
        System.out.println(formatOption);
        scanner.nextLine();
        
    }
        
        
    public void createTestData() {
        
        Person firstPerson = new Person("EDUARDO","PEREZ","3294734532");
        people.add(firstPerson);
        
        Person secondPerson = new Person("CLAUDIO","GUITIERREZ","3294734532");
        people.add(secondPerson);
        
        Person thirdPerson = new Person("STAR","BUTTERFLY","3294734532");
        people.add(thirdPerson);
        
    }  
    
    
    public static void main(String[] args) {
        
        Main main = new Main();
        
    }
    
}
